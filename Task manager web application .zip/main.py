
from flask import Flask, render_template, request, redirect, url_for, session, flash
from replit import db
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
import pytz  

app = Flask(__name__)
app.secret_key = 'ba7704c46658cbf422b2f19c'  

def get_user_tasks(username):
    return db.get(f'{username}_tasks', [])

@app.route('/')
def index():
    if 'username' in session:
        username = session['username']
        tasks = get_user_tasks(username)
        return render_template('index.html', tasks=tasks)
    return redirect(url_for('login'))

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        hashed_password = generate_password_hash(password)  

        if db.get(username):
            flash('Username already exists!')
        else:
            db[username] = hashed_password
            db[f'{username}_tasks'] = []
            flash('Registration successful! Please log in.')
            return redirect(url_for('login'))

    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        stored_password = db.get(username)

        if stored_password and check_password_hash(stored_password, password):
            session['username'] = username
            return redirect(url_for('index'))
        else:
            flash('Invalid username or password!')

    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect(url_for('login'))

@app.route('/add_task', methods=['POST'])
def add_task():
    if 'username' in session:
        username = session['username']
        title = request.form['title']
        description = request.form['description']
        tasks = get_user_tasks(username)
        task_no = len(tasks) + 1

        tz = pytz.timezone('Asia/Kolkata')
        local_time = datetime.now(tz)
        formatted_date = local_time.strftime("%d-%m-%Y")
        formatted_time = local_time.strftime("%I:%M  %p").lstrip('0') 

        task = {
            'task_no': task_no,
            'title': title,
            'description': description,
            'completed': False,
            'date': f"{formatted_date} {formatted_time}" 
        }
        
        tasks.append(task)
        db[f'{username}_tasks'] = tasks
    return redirect(url_for('index'))

@app.route('/complete_task/<int:task_index>')
def complete_task(task_index):
    if 'username' in session:
        username = session['username']
        tasks = get_user_tasks(username)
        if 0 <= task_index < len(tasks):
            tasks[task_index]['completed'] = True
            db[f'{username}_tasks'] = tasks
    return redirect(url_for('index'))

@app.route('/delete_task/<int:task_index>')
def delete_task(task_index):
    if 'username' in session:
        username = session['username']
        tasks = get_user_tasks(username)
        if 0 <= task_index < len(tasks):
            tasks.pop(task_index)
            db[f'{username}_tasks'] = tasks
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080, debug=True)
  